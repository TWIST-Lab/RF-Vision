# ICC-2025-Transmitter-middle > 2024-10-17 5:44pm
https://universe.roboflow.com/ieeeicc2025/icc-2025-transmitter-middle

Provided by a Roboflow user
License: CC BY 4.0


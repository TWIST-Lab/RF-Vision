import ultralytics

# Run ultralytics self-check
ultralytics.checks()

# Select the logging tool, set it to either 'Comet' or 'TensorBoard'
logger = 'Comet'  # Change to 'TensorBoard' to use TensorBoard

if logger == 'Comet':
    import comet_ml
    # Initialize comet_ml
    comet_ml.init()
elif logger == 'TensorBoard':
    import subprocess
    # Launch TensorBoard
    tb_process = subprocess.Popen(["tensorboard", "--logdir", "."])
    # Start YOLO training
    subprocess.check_call([
        "yolo", "train",
        "model=yolo11n.pt",
        "data=dataset.yaml",
        "epochs=100",
        "imgsz=640"
    ])
